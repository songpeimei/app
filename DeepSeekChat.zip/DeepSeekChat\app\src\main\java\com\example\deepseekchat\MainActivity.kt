package com.example.deepseekchat

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import com.google.gson.Gson
import com.google.gson.JsonObject

class MainActivity : AppCompatActivity() {
    
    private lateinit var apiKeyInput: EditText
    private lateinit var messageInput: EditText
    private lateinit var sendButton: Button
    private lateinit var responseText: TextView
    
    private val defaultApiKey = "sk-2f9837a88ecd4f7ca36bed5177441760"
    private val baseUrl = "https://api.deepseek.com"
    private val client = OkHttpClient()
    private val gson = Gson()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        apiKeyInput = findViewById(R.id.apiKeyInput)
        messageInput = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)
        responseText = findViewById(R.id.responseText)
        
        sendButton.setOnClickListener {
            sendMessage()
        }
    }
    
    private fun sendMessage() {
        val apiKey = apiKeyInput.text.toString().takeIf { it.isNotBlank() } ?: defaultApiKey
        val message = messageInput.text.toString()
        
        if (message.isBlank()) {
            responseText.text = "请输入消息"
            return
        }
        
        sendButton.isEnabled = false
        responseText.text = "正在请求..."
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = callDeepSeekAPI(apiKey, message)
                withContext(Dispatchers.Main) {
                    responseText.text = response
                    sendButton.isEnabled = true
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    responseText.text = "错误: ${e.message}"
                    sendButton.isEnabled = true
                }
            }
        }
    }
    
    private fun callDeepSeekAPI(apiKey: String, userMessage: String): String {
        val jsonBody = JsonObject().apply {
            addProperty("model", "deepseek-v4-pro")
            add("messages", gson.toJsonTree(listOf(
                mapOf("role" to "system", "content" to "You are a helpful assistant"),
                mapOf("role" to "user", "content" to userMessage)
            )))
            addProperty("stream", false)
            addProperty("reasoning_effort", "high")
        }
        
        val requestBody = gson.toJson(jsonBody)
            .toRequestBody("application/json".toMediaType())
        
        val request = Request.Builder()
            .url("$baseUrl/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(requestBody)
            .build()
        
        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: return "响应为空"
        
        val jsonResponse = gson.fromJson(responseBody, JsonObject::class.java)
        return jsonResponse.getAsJsonArray("choices")
            .get(0).asJsonObject
            .getAsJsonObject("message")
            .get("content").asString
    }
}
